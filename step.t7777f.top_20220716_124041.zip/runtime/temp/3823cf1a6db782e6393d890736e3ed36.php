<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"/www/wwwroot/step.t7777f.top/public/../application/index/view/admin/uinlist.html";i:1612065120;s:67:"/www/wwwroot/step.t7777f.top/application/index/view/admin/base.html";i:1612065120;}*/ ?>

<!DOCTYPE html>
<!--[if IE 9]>         <html class="ie9 no-focus"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-focus"> <!--<![endif]-->
<head>
    <meta charset="utf-8">

    <title>OneUI </title>

    <meta name="description" content="OneUI - Admin Dashboard Template & UI Framework">
    <meta name="author" content="pixelcave">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Icons -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel="shortcut icon" href="/assets/img/favicons/favicon.png">

    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-160x160.png" sizes="160x160">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-192x192.png" sizes="192x192">

    <link rel="apple-touch-icon" sizes="57x57" href="/assets/img/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/assets/img/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/assets/img/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/assets/img/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/assets/img/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/assets/img/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/assets/img/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/assets/img/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/img/favicons/apple-touch-icon-180x180.png">
    <!-- END Icons -->

    <!-- Stylesheets -->
    <!-- Web fonts -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">

    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="/assets/js/plugins/slick/slick.min.css">
    <link rel="stylesheet" href="/assets/js/plugins/slick/slick-theme.min.css">

    <!-- OneUI CSS framework -->
    <link rel="stylesheet" id="css-main" href="/assets/css/oneui.css">

    <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel="stylesheet" id="css-theme" href="/assets/css/themes/flat.min.css"> -->
    <!-- END Stylesheets -->
</head>
<body>
<!-- Page Container -->
<div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">
    <!-- Side Overlay-->

    <!-- END Side Overlay -->

    <!-- Sidebar -->
    <nav id="sidebar">
        <!-- Sidebar Scroll Container -->
        <div id="sidebar-scroll">
            <!-- Sidebar Content -->
            <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
            <div class="sidebar-content">
                <!-- Side Header -->
                <div class="side-header side-content bg-white-op">
                    <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                    <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                        <i class="fa fa-times"></i>
                    </button>
                    <!-- Themes functionality initialized in App() -> uiHandleTheme() -->
                    <div class="btn-group pull-right">
                        <button class="btn btn-link text-gray dropdown-toggle" data-toggle="dropdown" type="button">

                        </button>
                    </div>
                    <a class="h5 text-white" href="index.html">
                        <i class="fa fa-circle-o-notch text-primary"></i> <span class="h4 font-w600 sidebar-mini-hide">&nbsp;<?php echo config('title'); ?></span>
                    </a>
                </div>
                <!-- END Side Header -->

                <!-- Side Content -->
                <div class="side-content">
                    <ul class="nav-main">
                        <li>
                            <a  id="index" href="<?php echo url('index'); ?>"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">仪表盘</span></a>
                        </li>
                        <li class="nav-main-heading"><span class="sidebar-mini-hide">站点信息</span></li>
                        <li>
                            <a id="ulist" href="<?php echo url('ulist'); ?>"><i class="si si-user"></i><span class="sidebar-mini-hide">用户管理</span></a>
                        </li>
                        <li>
                            <a id="uinlist" href="<?php echo url('uinlist'); ?>"><i class="si si-badge"></i><span class="sidebar-mini-hide">账号管理</span></a>
                        </li>
                        <li>
                            <a id="km" href="<?php echo url('km'); ?>"><i class="si si-wallet"></i><span class="sidebar-mini-hide">卡密管理</span></a>
                        </li>
                        <li class="nav-main-heading"><span class="sidebar-mini-hide">其他功能</span></li>
                        <li>
                            <a id="data" href="<?php echo url('data'); ?>"><i class="si si-puzzle"></i><span class="sidebar-mini-hide">站点数据</span></a>
                        </li>
                        <li>
                            <a id="run" href="<?php echo url('run'); ?>"><i class="si si-wrench"></i><span class="sidebar-mini-hide">监控日志</span></a>
                        </li>
                    </ul>
                </div>
                <!-- END Side Content -->
            </div>
            <!-- Sidebar Content -->
        </div>
        <!-- END Sidebar Scroll Container -->
    </nav>
    <!-- END Sidebar -->

    <!-- Header -->
    <header id="header-navbar" class="content-mini content-mini-full">
        <!-- Header Navigation Right -->
        <ul class="nav-header pull-right">
            <li>
                <div class="btn-group">
                    <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                        <img src="/assets/img/avatars/avatar10.jpg" alt="Avatar">
                        <span class="caret"></span>
                    </button>
                </div>
            </li>
        </ul>
        <!-- END Header Navigation Right -->

        <!-- Header Navigation Left -->
        <ul class="nav-header pull-left">
            <li class="hidden-md hidden-lg">
                <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                    <i class="fa fa-navicon"></i>
                </button>
            </li>
            <li class="hidden-xs hidden-sm">
                <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
            </li>
        </ul>
        <!-- END Header Navigation Left -->
    </header>
    <!-- END Header -->
    <main id="main-container">
        
<div class="content bg-gray-lighter">
    <div class="row items-push">
        <div class="col-sm-7">
            <h1 class="page-heading">
                账号列表
            </h1>
        </div>
        <div class="col-sm-5 text-right hidden-xs">
            <ol class="breadcrumb push-10-t">
                <li>仪表盘</li>
                <li><a class="link-effect" href="">账号列表</a></li>
            </ol>
        </div>
    </div>
</div>
<div class="content">
    <div class="col-md-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3 class="panel-title">账号列表<span class="pull-right">共<?php echo db('uin')->count(); ?>个用户</span></h3>

            </div>
            <div class="panel-body">
                <?php if(is_array($uinlist) || $uinlist instanceof \think\Collection || $uinlist instanceof \think\Paginator): $i = 0; $__LIST__ = $uinlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?>
                <div class="col-xs-6 col-sm-3 col-md-3">
                    <div class="thumbnail" style="height:200px;">
                        <center style="margin-top:5%;">
                            <img src="/assets/img/avatars/avatar4.jpg" width="100" height="100" style="border-radius: 15px" class="img-thumbnail img-circle">
                            <br><br>
                            状态：<font color="<?php if($row['skcode']==1): ?>green<?php else: ?>red<?php endif; ?>"><?php if($row['skcode']==1): ?>正常<?php else: ?>失效<?php endif; ?></font>
                            <hr style="width:80%;margin-top: 5px;margin-bottom: 5px;">账号 : <?php echo $row['uin']; ?>
                            <a href="<?php echo url('uinlist',['do'=>'dell','qid'=>$row['qid']]); ?>" class="btn btn-xs btn-danger">删除</a>
                        </center>
                    </div></div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <?php echo $uinlist->render(); ?>
            </div>
        </div>
    </div>
</div>

    </main>
    <!-- END Main Container -->

    <!-- Footer -->
    <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
        <div class="pull-right">
            Crafted with <i class="fa fa-heart text-city"></i> by <a class="font-w600" href="" target="_blank"><?php echo config('adminuser'); ?></a>
        </div>
        <div class="pull-left">
            <a class="font-w600" href="javascript:void(0)" target="_blank"><?php echo config('title'); ?></a> &copy; <span class="js-year-copy"></span>
        </div>
    </footer>
    <!-- END Footer -->
</div>
<!-- END Page Container -->

<!-- Apps Modal -->
<!-- END Apps Modal -->

<!-- OneUI Core JS: jQuery, Bootstrap, slimScroll, scrollLock, Appear, CountTo, Placeholder, Cookie and App.js -->
<script src="/assets/js/core/jquery.min.js"></script>
<script src="/assets/js/core/bootstrap.min.js"></script>
<script src="/assets/js/core/jquery.slimscroll.min.js"></script>
<script src="/assets/js/core/jquery.scrollLock.min.js"></script>
<script src="/assets/js/core/jquery.appear.min.js"></script>
<script src="/assets/js/core/jquery.countTo.min.js"></script>
<script src="/assets/js/core/jquery.placeholder.min.js"></script>
<script src="/assets/js/core/js.cookie.min.js"></script>
<script src="/assets/js/app.js"></script>

<!-- Page Plugins -->
<script src="/assets/js/plugins/slick/slick.min.js"></script>
<script src="/assets/js/plugins/chartjs/Chart.min.js"></script>

<!-- Page JS Code -->
<script src="/assets/js/pages/base_pages_dashboard.js"></script>
<script src="/assets/layer/layer.js"></script>
<script>
    var aName = "<?php echo request()->action(); ?>";
    if (aName == 'info') {
        $("#info").addClass("active");
    } else {
        $("#" + aName).addClass("active");
    }

    $(function () {
        // Init page helpers (Slick Slider plugin)
        App.initHelpers('slick');
    });
</script>

</body>
</html>