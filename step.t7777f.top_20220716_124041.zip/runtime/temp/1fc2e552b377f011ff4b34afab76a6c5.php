<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/step.t7777f.top/public/../application/index/view/index/index.html";i:1612065120;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo config('title'); ?></title>
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/media/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/media/favicons/apple-touch-icon-180x180.png">
    <link rel="stylesheet" type="text/css" href="/assets/index/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="/assets/index/css/main.css">
</head>

<body>
<div class="preloader">
    <div class="spinner">
        <div class="bounce-1"></div>
        <div class="bounce-2"></div>
        <div class="bounce-3"></div>
    </div>
</div>
<div class="hero">
    <div class="front-content">
        <div class="container-mid">
            <div class="animation-container animation-fade-right" data-animation-delay="300">
                <h1><?php echo config('title'); ?></h1>
            </div>
            <div class="animation-container animation-fade-left" data-animation-delay="600">
                <p class="subline">一款专业的运动数据的网站</p>
            </div>
            <div class="animation-container animation-fade-up" data-animation-delay="900">
                <div class="open-popup">Let's Go ！</div>
            </div>
        </div>
    </div>
    <div class="background-content parallax-on">
        <div class="background-overlay"></div>
        <div class="background-img layer" data-depth="0.05"></div>
    </div>
</div>
<script type="text/javascript" src="/assets/index/js/plugins.js"></script>
<script type="text/javascript" src="/assets/index/js/main.js"></script>
</body>

</html>