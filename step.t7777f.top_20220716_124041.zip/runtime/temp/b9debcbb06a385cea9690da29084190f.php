<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"/www/wwwroot/step.t7777f.top/public/../application/index/view/user/uinconfig.html";i:1655990130;s:66:"/www/wwwroot/step.t7777f.top/application/index/view/user/base.html";i:1612065120;}*/ ?>

<!DOCTYPE html>
<!--[if IE 9]>         <html class="ie9 no-focus"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-focus"> <!--<![endif]-->
<head>
    <meta charset="utf-8">

    <title>账号列表-<?php echo config('title'); ?></title>

    <meta name="description" content="OneUI - Admin Dashboard Template & UI Framework">
    <meta name="author" content="pixelcave">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Icons -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel="shortcut icon" href="/assets/img/favicons/favicon.png">

    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-160x160.png" sizes="160x160">
    <link rel="icon" type="image/png" href="/assets/img/favicons/favicon-192x192.png" sizes="192x192">

    <link rel="apple-touch-icon" sizes="57x57" href="/assets/img/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/assets/img/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/assets/img/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/assets/img/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/assets/img/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/assets/img/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/assets/img/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/assets/img/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/img/favicons/apple-touch-icon-180x180.png">
    <!-- END Icons -->

    <!-- Stylesheets -->
    <!-- Web fonts -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">

    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="/assets/js/plugins/slick/slick.min.css">
    <link rel="stylesheet" href="/assets/js/plugins/slick/slick-theme.min.css">

    <!-- OneUI CSS framework -->
    <link rel="stylesheet" id="css-main" href="/assets/css/oneui.css">

    <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel="stylesheet" id="css-theme" href="/assets/css/themes/flat.min.css"> -->
    <!-- END Stylesheets -->
</head>
<body>
<!-- Page Container -->
<div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">
    <!-- Side Overlay-->

    <!-- END Side Overlay -->

    <!-- Sidebar -->
    <nav id="sidebar">
        <!-- Sidebar Scroll Container -->
        <div id="sidebar-scroll">
            <!-- Sidebar Content -->
            <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
            <div class="sidebar-content">
                <!-- Side Header -->
                <div class="side-header side-content bg-white-op">
                    <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                    <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                        <i class="fa fa-times"></i>
                    </button>
                    <!-- Themes functionality initialized in App() -> uiHandleTheme() -->
                    <div class="btn-group pull-right">
                        <button class="btn btn-link text-gray dropdown-toggle" data-toggle="dropdown" type="button">

                        </button>
                    </div>
                    <a class="h5 text-white" href="index.html">
                        <i class="fa fa-circle-o-notch text-primary"></i> <span class="h4 font-w600 sidebar-mini-hide">&nbsp;<?php echo config('title'); ?></span>
                    </a>
                </div>
                <!-- END Side Header -->

                <!-- Side Content -->
                <div class="side-content">
                    <ul class="nav-main">
                        <li>
                            <a  id="index" href="<?php echo url('index'); ?>"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">仪表盘</span></a>
                        </li>
                        <li>
                            <a  id="userinfo" href="<?php echo url('userinfo'); ?>"><i class="si si-settings"></i><span class="sidebar-mini-hide">个人资料</span></a>
                        </li>
                        <li class="nav-main-heading"><span class="sidebar-mini-hide">账号功能</span></li>
                        <li>
                            <a id="add" href="<?php echo url('add'); ?>"><i class="si si-plus"></i><span class="sidebar-mini-hide">添加账号</span></a>
                        </li>
                        <li>
                            <a id="uinlist" href="<?php echo url('uinlist'); ?>"><i class="si si-grid"></i><span class="sidebar-mini-hide">账号列表</span></a>
                        </li>
                        <li class="nav-main-heading"><span class="sidebar-mini-hide">其他功能</span></li>
                        <li>
                            <a id="km" href="<?php echo url('km'); ?>"><i class="si si-wallet"></i><span class="sidebar-mini-hide">使用卡密</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('logout'); ?>"><i class="si si-logout"></i><span class="sidebar-mini-hide">安全退出</span></a>
                        </li>
                    </ul>
                </div>
                <!-- END Side Content -->
            </div>
            <!-- Sidebar Content -->
        </div>
        <!-- END Sidebar Scroll Container -->
    </nav>
    <!-- END Sidebar -->

    <!-- Header -->
    <header id="header-navbar" class="content-mini content-mini-full">
        <!-- Header Navigation Right -->
        <ul class="nav-header pull-right">
            <li>
                <div class="btn-group">
                    <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                        <img src="/assets/img/avatars/avatar10.jpg" alt="Avatar">
                        <span class="caret"></span>
                    </button>
                </div>
            </li>
        </ul>
        <!-- END Header Navigation Right -->

        <!-- Header Navigation Left -->
        <ul class="nav-header pull-left">
            <li class="hidden-md hidden-lg">
                <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                    <i class="fa fa-navicon"></i>
                </button>
            </li>
            <li class="hidden-xs hidden-sm">
                <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
            </li>
        </ul>
        <!-- END Header Navigation Left -->
    </header>
    <!-- END Header -->
    <main id="main-container">
    
<div class="content bg-gray-lighter">
    <div class="row items-push">
        <div class="col-sm-7">
            <h1 class="page-heading">
                <?php echo input('uin'); ?>
            </h1>
        </div>
        <div class="col-sm-5 text-right hidden-xs">
            <ol class="breadcrumb push-10-t">
                <li>仪表盘</li>
                <li><a class="link-effect" href="">账号列表</a></li>
            </ol>
        </div>
    </div>
</div>
<div class="content">
    <div class="row">
        <div class="col-lg-8 col-md-12 col-lg-offset-2">
            <div class="panel panel-default">
                <div style="background-image: url('/assets/img/photos/photo8@2x.jpg')" class="panel-body bg-center">
                    <div class="row row-table">
                        <div class="col-xs-12 text-center text-white">
              <span class="qqtouxiang">
                <img src="/assets/img/avatars/avatar13.jpg" class="img-thumbnail img-circle thumb128 mv"></span>
                            <br><br>

                            <h4 class="mv-sm qqhao"><?php echo $row['uin']; ?></h4></div>
                    </div>
                </div>
                <div class="panel-body text-center bg-gray-darker">
                    <div class="row row-table">
                        <?php if($row['skcode']==1): ?>
                        <h4 class="text-info m0">账号在线状态：正常</h4>
                        <div class="mt-sm">状态若显示失效请及时更新防止功能不运行</div>
                        <?php else: ?>
                        <h4 class="text-danger m0">账号在线状态：失效</h4>
                        <div class="mt-sm">状态若显示失效请及时更新防止功能不运行</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="block">
                <ul class="nav nav-tabs nav-tabs-alt nav-justified" data-toggle="tabs">
                    <li class="active">
                        <a href="#btabs-alt-static-justified-home"><i class="si si-cloud-download"></i> 日志运行</a>
                    </li>
                    <li class="">
                        <a href="#btabs-alt-static-justified-profile"><i class="fa fa-pencil"></i> 修改步数</a>
                    </li>
                    <li>
                        <a href="#btabs-alt-static-justified-settings"><i class="fa fa-cog"></i> 修改密码</a>
                    </li>
                </ul>
                <div class="block-content tab-content">
                    <div class="tab-pane active" id="btabs-alt-static-justified-home">
                        <?php if(is_array($log) || $log instanceof \think\Collection || $log instanceof \think\Paginator): $i = 0; $__LIST__ = $log;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$log): $mod = ($i % 2 );++$i;?>
                        <div class="alert alert-success alert-dismissable">
                            <?php echo $log['log']; ?><br><?php echo $log['logtime']; ?>
                        </div>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </div>
                    <div class="tab-pane" id="btabs-alt-static-justified-profile">
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h3 class="font-w300 push-15">提示</h3>
                            <p>当前步数 <a class="alert-link" href="javascript:void(0)"><?php echo $row['steps']; ?></a> 步!</p>
                        </div>
                        <div class="form-group">
                            <label>修改步数</label>
                            <input class="form-control" type="text" id="steps" name="steps" placeholder="请输入修改的步数..">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-sm btn-primary" type="submit" href="javascript:setsteps('<?php echo $row['qid']; ?>')">修 改</a>
                        </div>
                    </div>
                    <div class="tab-pane" id="btabs-alt-static-justified-settings">
                        <form id="doForm" onsubmit="return false" action="#" method="post">
                        <div class="alert alert-success alert-dismissable">
                            <div class="form-group">
                                <input style="display:none" name="qid" id="qid" value="<?php echo $row['qid']; ?>">
                            </div>
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h3 class="font-w300 push-15">提示</h3>
                            <p>请去添加账号页面进行更新(输入更新账号和密码添加即可)</p>
                            <p>在到期范围内才可使用自动刷步数</p>
                            <p>执行刷步数时，会取 +-300 的随机数</p>
                        </div>
                        <div class="form-group">
                                <label>状态</label>
                                <select name="status" id="status" class="form-control" >
                                    <?php if($row['skcode']==1): ?>
                                    <option value="1" selected>启用</option>
                                    <option value="0" >禁用</option>
                                    <?php else: ?>
                                    <option value="1" >启用</option>
                                    <option value="0" selected>禁用</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>账号</label>
                                <input class="form-control" type="text" id="uin" name="uin" placeholder="请输入账号" value="<?php echo $row['uin']; ?>">
                            </div>
                            <div class="form-group">
                                <label>密码</label>
                                <input class="form-control" type="text" id="pwd" name="pwd" placeholder="请输入密码" value="<?php echo $row['pwd']; ?>">
                            </div>
                                                        <div class="form-group">
                                <label>0点-1点</label>
                                <input type="number" autocomplete="off" id="hour_0" value="<?php echo $row['hour_0']; ?>" name="hour_0"
                                       class="form-control" placeholder="请输入0点-1点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>1点-2点</label>
                                <input type="number" autocomplete="off" id="hour_1" value="<?php echo $row['hour_1']; ?>" name="hour_1"
                                       class="form-control" placeholder="请输入1点-2点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>2点-3点</label>
                                <input type="number" autocomplete="off" id="hour_2" value="<?php echo $row['hour_2']; ?>" name="hour_2"
                                       class="form-control" placeholder="请输入2点-3点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>3点-4点</label>
                                <input type="number" autocomplete="off" id="hour_3" value="<?php echo $row['hour_3']; ?>" name="hour_3"
                                       class="form-control" placeholder="请输入3点-4点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>4点-5点</label>
                                <input type="number" autocomplete="off" id="hour_4" value="<?php echo $row['hour_4']; ?>" name="hour_4"
                                       class="form-control" placeholder="请输入4点-5点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>5点-6点</label>
                                <input type="number" autocomplete="off" id="hour_5" value="<?php echo $row['hour_5']; ?>" name="hour_5"
                                       class="form-control" placeholder="请输入5点-6点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>6点-7点</label>
                                <input type="number" autocomplete="off" id="hour_6" value="<?php echo $row['hour_6']; ?>" name="hour_6"
                                       class="form-control" placeholder="请输入6点-7点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>7点-8点</label>
                                <input type="number" autocomplete="off" id="hour_7" value="<?php echo $row['hour_7']; ?>" name="hour_7"
                                       class="form-control" placeholder="请输入7点-8点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>8点-9点</label>
                                <input type="number" autocomplete="off" id="hour_8" value="<?php echo $row['hour_8']; ?>" name="hour_8"
                                       class="form-control" placeholder="请输入8点-9点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>9点-10点</label>
                                <input type="number" autocomplete="off" id="hour_9" value="<?php echo $row['hour_9']; ?>" name="hour_9"
                                       class="form-control" placeholder="请输入9点-10点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>10点-11点</label>
                                <input type="number" autocomplete="off" id="hour_10" value="<?php echo $row['hour_10']; ?>" name="hour_10"
                                       class="form-control" placeholder="请输入10点-11点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>11点-12点</label>
                                <input type="number" autocomplete="off" id="hour_11" value="<?php echo $row['hour_11']; ?>" name="hour_11"
                                       class="form-control" placeholder="请输入11点-12点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>12点-13点</label>
                                <input type="number" autocomplete="off" id="hour_12" value="<?php echo $row['hour_12']; ?>" name="hour_12"
                                       class="form-control" placeholder="请输入12点-13点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>13点-14点</label>
                                <input type="number" autocomplete="off" id="hour_13" value="<?php echo $row['hour_13']; ?>" name="hour_13"
                                       class="form-control" placeholder="请输入13点-14点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>14点-15点</label>
                                <input type="number" autocomplete="off" id="hour_14" value="<?php echo $row['hour_14']; ?>" name="hour_14"
                                       class="form-control" placeholder="请输入14点-15点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>15点-16点</label>
                                <input type="number" autocomplete="off" id="hour_15" value="<?php echo $row['hour_15']; ?>" name="hour_15"
                                       class="form-control" placeholder="请输入15点-16点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>16点-17点</label>
                                <input type="number" autocomplete="off" id="hour_16" value="<?php echo $row['hour_16']; ?>" name="hour_16"
                                       class="form-control" placeholder="请输入16点-17点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>17点-18点</label>
                                <input type="number" autocomplete="off" id="hour_17" value="<?php echo $row['hour_17']; ?>" name="hour_17"
                                       class="form-control" placeholder="请输入17点-18点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>18点-19点</label>
                                <input type="number" autocomplete="off" id="hour_18" value="<?php echo $row['hour_18']; ?>" name="hour_18"
                                       class="form-control" placeholder="请输入18点-19点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>19点-20点</label>
                                <input type="number" autocomplete="off" id="hour_19" value="<?php echo $row['hour_19']; ?>" name="hour_19"
                                       class="form-control" placeholder="请输入19点-20点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>20点-21点</label>
                                <input type="number" autocomplete="off" id="hour_20" value="<?php echo $row['hour_20']; ?>" name="hour_20"
                                       class="form-control" placeholder="请输入20点-21点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>21点-22点</label>
                                <input type="number" autocomplete="off" id="hour_21" value="<?php echo $row['hour_21']; ?>" name="hour_21"
                                       class="form-control" placeholder="请输入21点-22点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>22点-23点</label>
                                <input type="number" autocomplete="off" id="hour_22" value="<?php echo $row['hour_22']; ?>" name="hour_22"
                                       class="form-control" placeholder="请输入22点-23点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <label>23点-24点</label>
                                <input type="number" autocomplete="off" id="hour_23" value="<?php echo $row['hour_23']; ?>" name="hour_23"
                                       class="form-control" placeholder="请输入23点-24点刷入的步数" min="0" step="1" max="99980">
                            </div>
                                                        <div class="form-group">
                                <a class="btn btn-sm btn-primary" type="button" href="javascript:update()">修改</a>
                            </div>
                         </form>
                    </div>
                </div>
            </div>
            <!-- END Block Tabs Justified Default Style -->
        </div>
    </div>
</div>

    </main>
    <!-- END Main Container -->

    <!-- Footer -->
    <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
        <div class="pull-right">
            Crafted with <i class="fa fa-heart text-city"></i> by <a class="font-w600" href="" target="_blank"><?php echo config('adminuser'); ?></a>
        </div>
        <div class="pull-left">
            <a class="font-w600" href="javascript:void(0)" target="_blank"><?php echo config('title'); ?></a> &copy; <span class="js-year-copy"></span>
        </div>
    </footer>
    <!-- END Footer -->
</div>
<!-- END Page Container -->

<!-- Apps Modal -->
<!-- END Apps Modal -->

<!-- OneUI Core JS: jQuery, Bootstrap, slimScroll, scrollLock, Appear, CountTo, Placeholder, Cookie and App.js -->
<script src="/assets/js/core/jquery.min.js"></script>
<script src="/assets/js/core/bootstrap.min.js"></script>
<script src="/assets/js/core/jquery.slimscroll.min.js"></script>
<script src="/assets/js/core/jquery.scrollLock.min.js"></script>
<script src="/assets/js/core/jquery.appear.min.js"></script>
<script src="/assets/js/core/jquery.countTo.min.js"></script>
<script src="/assets/js/core/jquery.placeholder.min.js"></script>
<script src="/assets/js/core/js.cookie.min.js"></script>
<script src="/assets/js/app.js"></script>

<!-- Page Plugins -->
<script src="/assets/js/plugins/slick/slick.min.js"></script>
<script src="/assets/js/plugins/chartjs/Chart.min.js"></script>

<!-- Page JS Code -->
<script src="/assets/js/pages/base_pages_dashboard.js"></script>
<script src="/assets/layer/layer.js"></script>
<script>
    var aName = "<?php echo request()->action(); ?>";
    if (aName == 'info') {
        $("#info").addClass("active");
    } else {
        $("#" + aName).addClass("active");
    }

    $(function () {
        // Init page helpers (Slick Slider plugin)
        App.initHelpers('slick');
    });
</script>

<script>
    function update(){
        $.ajax({
            type:"post",
            url:"/ajax?act=update",
            data:$('#doForm').serialize(),
            dataType:"json",
            success:function(data){
                if(data.code==0){
                    layer.msg(data.msg,{icon:1,shade:0.3});
                    setTimeout("top.location.href = '/user/uinlist'",3000);
                }else{
                    layer.msg(data.msg,{icon:2,shade:0.3});
                }
            }
        });
    }
    function setsteps(qid){
        $.ajax({
            type:"post",
            url:"/ajax?act=setsteps",
            data:{
                qid:qid,
                steps:$("#steps").val()
            },
            dataType:"json",
            success:function(data){
                if(data.code==0){
                    layer.msg(data.msg,{icon:1,shade:0.3});
                    setTimeout("top.location.href = '/user/uinlist'",3000);
                }else{
                    layer.msg(data.msg,{icon:2,shade:0.3});
                }
            }
        });
    }
</script>

</body>
</html>