var SinKingMusic = {
    /*核心API地址*/
    MainApiDomain: "https://music.clwl.online",
    MainApiUrls: {
        MusicList: "/api/player",
        MusicInfo: "/api/music",
        MusicStyle: "/Player/player.min.css",
        MusicImg: "https://music.clwl.online/api/proxy?url="
    },
    Start: function (CallBack = null) {
        var strVar = '<link rel="stylesheet" type="text/css" href="' + SinKingMusic.MainApiDomain + SinKingMusic.MainApiUrls.MusicStyle + '">' + "<div class=\"SinKingCloudPlayer\"><div id=\"SinKingMusicPlayer\" class=\"Open rovate-180\"><div id=\"MusicLogo\"><div id=\"SinKingMain\"><div id=\"SinKingMainBackGround\"><\/div><\/div><div id=\"MainLogo\"><div class=\"center Logo\"><div class=\"center\" id=\"MainLogoButton\"><span onclick=\"SinKingMusic.Player.Toggle()\" class=\"SinKingFont Playerplay Pause MainLogoButton-On Ani-Music\"><\/span><\/div><\/div><\/div><div id=\"MainInfo\"><div class=\"sinking-row info\"><div class=\"item-1 \"><i class=\"SinKingFont Notemelody SinKingicon\"><\/i> <span id=\"SinKingSongName\">加载中...<\/span><\/div><div class=\"item-1 right\"><i class=\"SinKingFont timers SinKingicon\" style=\"margin-right:-3px\"><\/i> <span id=\"SinKingSongBeen\">00:00<\/span> / <span id=\"SinKingSongTime\">00:00<\/span><\/div><\/div><div class=\"sinking-row info\"><div class=\"item-1 \"><i class=\"SinKingFont yonghu SinKingicon\"><\/i> <span id=\"SinKingSinger\">加载中...<\/span><\/div><div class=\"item-1 right\"><i class=\"SinKingFont Lensshutter SinKingicon\"><\/i> <span id=\"SinKingPlayType\">加载中...<\/span><\/div><\/div><div class=\"sinking-row info\"><div class=\"item-1 \"><i class=\"SinKingFont special SinKingicon\"><\/i> <span id=\"SinKingSheetName\">加载中...<\/span><\/div><div class=\"item-1 right\"><i class=\"SinKingFont succ SinKingicon\"><\/i> <span id=\"SinKingLyric\">加载中...<\/span><\/div><\/div><\/div><div id=\"MainHandle\"><div class=\"sinking-row sinking-panel\"><div class=\"item-1 sinking-fixed\"><i class=\"SinKingFont Playernext2 icon2\" onclick=\"SinKingMusic.Buttons.LastSheet()\"><\/i> <i class=\"SinKingFont Playerfastforward2 icon2\" onclick=\"SinKingMusic.Buttons.LastMusic(!0)\"><\/i><\/div><div class=\"item-1 right\"><i class=\"SinKingFont Playerfastforward icon2\" onclick=\"SinKingMusic.Buttons.NextMusic(!0)\"><\/i> <i class=\"SinKingFont Playernext icon2\" onclick=\"SinKingMusic.Buttons.NextSheet()\"><\/i><\/div><\/div><\/div><\/div><div id=\"MusicPanel\"><div class=\"sinking-row\"><div class=\"item-1\"><i class=\"SinKingFont voice SinKingicon voice-set\"><div class=\"voice-panel\"><div class=\"voice-bg\" id=\"MusicVoiceClick\"><div class=\"voice-been\" id=\"MusicVoiceBeen\"><div class=\"voice-bar\" id=\"MusicVoiceBtn\"><\/div><\/div><\/div><\/div><\/i><i class=\"SinKingFont single2 SinKingicon\" onclick=\"SinKingMusic.Buttons.PlayType.Change()\"><\/i><\/div><div class=\"item-9\"><div class=\"process\"><div style=\"position:absolute;background-color:#9b9b9b;width:0\" class=\"process_bg\" id=\"MusicProcess\"><\/div><div style=\"position:absolute;background-color:#646464\" class=\"process_bg\" id=\"MusicProcessBtn\"><\/div><div class=\"process_bg\" id=\"MusicMainProcess\"><\/div><div id=\"MusicTimeBtn\" class=\"process_btn\"><\/div><\/div><\/div><div class=\"item-1 right\"><i class=\"SinKingFont off SinKingicon\" id=\"SinKingLyric2\" onclick=\"SinKingMusic.Lyric.Toggle()\"><\/i> <i class=\"SinKingFont sinking-menu SinKingicon\" onclick=\"SinKingMusic.MusicListStatu.Toggle()\"><\/i><\/div><\/div><\/div><div id=\"MusicList\"><div class=\"SongSheetName\" id=\"SongSheetInfo\"><div style=\"overflow:hidden;position:relative;width:12px;height:20px;float:left\"><i class=\"SinKingFont arrow-down SinKingicon rovate-180\"><\/i><\/div><span class=\"title\">加载中...<\/span><\/div><div class=\"MusicList\"><div id=\"MusicLists\"><div class=\"MusicContain Lighten\"><div class=\"Box\" id=\"SongSheets\"><ul style=\"margin:0;padding:0\" id=\"LoadSongSheets\"><li>加载中...<\/li><\/ul><\/div><div class=\"Box\" id=\"SongList\"><ul style=\"margin:0;padding:0\" id=\"LoadMusicLists\"><li>加载中...<\/li><\/ul><\/div><\/div><\/div><\/div><\/div><div id=\"MusicButton\" onclick=\"SinKingMusic.PlayerStatu.Toggle()\"><i class=\"SinKingFont arrow-down SinKingicon\"><\/i><\/div><\/div><div id=\"MusicTips\" class=\"Close\">加载中...<\/div><div id=\"MusicLyrics\" style=\"z-index:9999999999\" class=\"Close\"><div class=\"sinking-row\"><div class=\"item-1 Bounce\" style=\"text-align:center\">加载中...<\/div><\/div><\/div><\/div>\n";
        document.body.insertAdjacentHTML("beforeend", strVar);
        SinKingMusic.PlayerStatu.Ele = document.getElementById("MusicButton").children[0];
        SinKingMusic.Ele = document.getElementById("SinKingMusicPlayer");
        SinKingMusic.MusicListStatu.Ele = document.getElementById("MusicList");
        SinKingMusic.Lyric.Ele = [
            document.getElementById("SinKingLyric"),
            document.getElementById("SinKingLyric2"),
            document.getElementById("MusicLyrics")
        ];
        SinKingMusic.Tips.Ele = document.getElementById("MusicTips");
        SinKingMusic.Buttons.PlayType.Ele = [
            document.getElementById("SinKingPlayType")
        ];
        if (CallBack != null && CallBack != undefined) {
            CallBack();
        }
    },
    Audio: document.createElement("audio"),//音频属性
    Timer: {
        Timer: null,
        Status: true,
        Start: function () {
            this.Stop();
            let SinKingSongBeen = document.getElementById("SinKingSongBeen");
            let SinKingSongTime = document.getElementById("SinKingSongTime");
            let MusicProcess = document.getElementById("MusicProcess");
            let MusicProcessBtn = document.getElementById("MusicProcessBtn");
            let MusicTimeBtn = document.getElementById("MusicTimeBtn");
            let width = MusicProcess.parentElement.offsetWidth;
            SinKingMusic.Timer.Timer = setInterval(function () {
                try {
                    if (SinKingMusic.Audio.src == "" || SinKingMusic.Audio.src == null || SinKingMusic.Audio.src == undefined || !SinKingMusic.Timer.Status) {
                        return;
                    }
                    if(SinKingMusic.Player.Statu()==true&&SinKingMusic.Player.Statu()==SinKingMusic.Audio.paused){
                        setTimeout(function(){
                            SinKingMusic.Tips.Show("请手动播放音乐 . . . ");
                        },2500);
                        SinKingMusic.Player.Stop(false);
                    }
                    if (isNaN(SinKingMusic.Audio.duration) || SinKingMusic.Audio.buffered.length <= 0) {
                        SinKingMusic.Tips.Show("正在加载 . . . ");
                        return;
                    }
                    if ((SinKingMusic.Audio.currentTime >= SinKingMusic.Audio.duration && SinKingMusic.Timer.Status) && SinKingMusic.Audio.currentTime > 0) {
                        SinKingMusic.Tips.Show("开始播放下一首");
                        SinKingMusic.Timer.Status = false;
                        SinKingMusic.Buttons.NextMusic();
                        return;
                    }
                    let temptime = parseInt(SinKingMusic.Audio.buffered.end(0) >= SinKingMusic.Audio.duration ? SinKingMusic.Audio.buffered.end(0) : SinKingMusic.Audio.duration);
                    let temp = parseFloat(temptime / SinKingMusic.Audio.duration).toFixed(2);
                    MusicProcess.style.width = width * temp + "px";
                    let time = (SinKingMusic.Audio.currentTime / SinKingMusic.Audio.duration * width);
                    MusicProcessBtn.style.width = time + "px";
                    MusicTimeBtn.style.left = time + "px";
                    if (SinKingMusic.Audio.currentTime >= 0 && SinKingMusic.Audio.currentTime != undefined) {
                        SinKingSongBeen.innerText = SinKingMusic.timeToMinute(parseInt(SinKingMusic.Audio.currentTime));
                    }
                    if (SinKingMusic.Audio.duration >= 0 && SinKingMusic.Audio.duration != undefined) {
                        SinKingSongTime.innerText = SinKingMusic.timeToMinute(parseInt(SinKingMusic.Audio.duration));
                    }
                    SinKingMusic.Cache.Set("SinKingMusicCurrentTime", parseFloat(SinKingMusic.Audio.currentTime));
                    if ((temptime <= parseInt(SinKingMusic.Audio.currentTime) + 1) && parseInt(SinKingMusic.Audio.buffered.end(0)) < parseInt(SinKingMusic.Audio.duration)) {
                        SinKingMusic.Tips.Show("正在缓冲 . . . ");
                        return;
                    }
                } catch (error) {
                    return error;
                }
            }, 500);
            SinKingMusic.Audio.onerror = function () {
                SinKingMusic.Tips.Show("播放错误，开始播放下一首");
                SinKingMusic.Buttons.NextMusic(true);
            }
        },
        Stop: function () {
            clearInterval(SinKingMusic.Timer.Timer);
        }
    },
    /*播放器操作*/
    Player: {
        Timer: null,
        Statu: function () {
            let ele = document.getElementById("MainLogoButton").children[0];
            return !ele.classList.contains("MainLogoButton-On");
        },
        /*音乐开启*/
        Start: function (cache = true) {
            try {
                let ele = document.getElementById("MainLogoButton").children[0];
                ele.parentElement.style.animation = "PauseRoate 10s linear infinite";
                ele.parentElement.parentElement.style.animation = "LogoRoate 10s linear infinite";
                ele.classList.remove("MainLogoButton-On");
                ele.classList.remove("Playerplay");
                ele.classList.add("Playerpause");
                ele.classList.remove("Ani-Music");
                setTimeout(function () {
                    ele.classList.add("Ani-Music");
                }, 100);
                SinKingMusic.Audio.play();
                SinKingMusic.Timer.Status = true;
                if(cache){
                    SinKingMusic.Cache.Set("SinKingMusicPlayStatus", 1);
                }
                if (parseInt(SinKingMusic.Cache.Get("SinKingMusicLyric")) == 1 && SinKingMusic.Lyric.Data.length > 0) {
                    SinKingMusic.Lyric.Open(false);
                }
            } catch (error) {
                return error;
            }
        },
        /*音乐关闭*/
        Stop: function (cache = true) {
            let ele = document.getElementById("MainLogoButton").children[0];
            ele.parentElement.style.animation = "";
            ele.parentElement.parentElement.style.animation = "";
            ele.classList.add("MainLogoButton-On");
            ele.classList.add("Playerplay");
            ele.classList.remove("Playerpause");
            ele.classList.remove("Ani-Music");
            setTimeout(function () {
                ele.classList.add("Ani-Music");
            }, 100);
            SinKingMusic.Audio.pause();
            if(cache){
                SinKingMusic.Cache.Set("SinKingMusicPlayStatus", 0);
            }
            if (parseInt(SinKingMusic.Cache.Get("SinKingMusicLyric")) == 1 && SinKingMusic.Lyric.Data.length > 0) {
                SinKingMusic.Lyric.Close(false);
            }
        },
        /*开启/关闭*/
        Toggle: function () {
            if (this.Statu()) {
                this.Stop();
            } else {
                this.Start();
            }
        },
        /*播放*/
        Play: function (SheetID, MusicID) {
            SinKingMusic.Player.Load(SheetID, MusicID, function () {
                SinKingMusic.Player.Start();
            });
        },
        /*变亮*/
        Lighten: function () {
            let MainInfo = document.getElementById("MainInfo");
            MainInfo.style.color = "white";
            let MainHandle = document.getElementById("MainHandle");
            MainHandle.style.color = "rgba(255, 255, 255, 0.7)";
            let MainLogo = document.getElementById("MainLogo");
            MainLogo.children[0].style.border = "5px solid rgba(255, 255, 255, 0.7)";
            let MainLogoButton = document.getElementById("MainLogoButton");
            MainLogoButton.children[0].style.color = "rgba(255,255,255,0.7)";
            MainLogoButton.children[0].style.border = "3px solid rgba(255,255,255,0.7)";
            let SongSheetInfo = document.getElementById("SongSheetInfo");
            SongSheetInfo.style.color = "rgba(255,255,255,0.7)";
            let MusicLyrics = document.getElementById("MusicLyrics");
            MusicLyrics.style.color = "white";
            let MusicTips = document.getElementById("MusicTips");
            MusicTips.style.color = "white";
            let MusicLists = document.getElementById("MusicLists");
            MusicLists.children[0].classList.remove("Darken");
            MusicLists.children[0].classList.add("Lighten");
        },
        /*变暗*/
        Darken: function () {
            let MainInfo = document.getElementById("MainInfo");
            MainInfo.style.color = "black";
            let MainHandle = document.getElementById("MainHandle");
            MainHandle.style.color = "rgba(0, 0, 0, 0.7)";
            let MainLogo = document.getElementById("MainLogo");
            MainLogo.children[0].style.border = "5px solid rgba(0, 0, 0, 0.7)";
            let MainLogoButton = document.getElementById("MainLogoButton");
            MainLogoButton.children[0].style.color = "rgba(0,0,0,0.7)";
            MainLogoButton.children[0].style.border = "3px solid rgba(0,0,0,0.7)";
            let SongSheetInfo = document.getElementById("SongSheetInfo");
            SongSheetInfo.style.color = "rgba(0,0,0,0.7)";
            let MusicLyrics = document.getElementById("MusicLyrics");
            MusicLyrics.style.color = "black";
            let MusicTips = document.getElementById("MusicTips");
            MusicTips.style.color = "black";
            let MusicLists = document.getElementById("MusicLists");
            MusicLists.children[0].classList.remove("Lighten");
            MusicLists.children[0].classList.add("Darken");
        },
        StyleToggle:function(){
            if(document.getElementById("MainInfo").style.color == "white"){
                SinKingMusic.Player.Darken();
            }else{
                SinKingMusic.Player.Lighten();
            }
        },
        /*加载歌曲信息*/
        Load: function (SheetID, MusicID, CallBack = null) {
            if (SheetID == null) {
                if (isNaN(parseInt(SinKingMusic.Cache.Get("SinKingMusicSheetID")))) {
                    SheetID = SinKingMusic.MusicList.Data.Data[0].ID;
                } else {
                    SheetID = SinKingMusic.Cache.Get("SinKingMusicSheetID");
                }
            }
            if (MusicID == null) {
                if (isNaN(parseInt(SinKingMusic.Cache.Get("SinKingMusicMusicID")))) {
                    MusicID = SinKingMusic.MusicList.Data.Data[0].MusicList[0].ID;
                } else {
                    MusicID = SinKingMusic.Cache.Get("SinKingMusicMusicID");
                }
            }
            clearTimeout(SinKingMusic.Player.Timer);
            if (SheetID != SinKingMusic.Cache.Get("SinKingMusicSheetID") && MusicID != SinKingMusic.Cache.Get("SinKingMusicMusicID")) {
                SinKingMusic.Cache.Set("SinKingMusicCurrentTime", 0);
            }
            SinKingMusic.Tips.Show("正在切换中...");
            SinKingMusic.Player.Timer = setTimeout(function () {
                let UserMusicList = SinKingMusic.MusicList.FindMusic(SheetID, MusicID);
                if (UserMusicList == null) {
                    return false;
                }
                try {
                    SinKingMusic.Ajax({
                        url: SinKingMusic.MainApiDomain + SinKingMusic.MainApiUrls.MusicInfo,
                        data: {
                            callback: "MusicInfo",
                            type: UserMusicList.MusicType,
                            id: UserMusicList.MusicID,
                            lrc: true//,
                            //rand:Math.random()
                        },
                        jsonp: 'MusicInfo',
                        time: 10000,
                        success: function (res) {
                            try {
                                document.getElementById("SinKingSongName").innerText = UserMusicList.Name;
                                document.getElementById("SinKingSinger").innerText = UserMusicList.Singer;
                                document.getElementById("SinKingSheetName").innerText = UserMusicList.AlbumName;
                                document.getElementById("SinKingSongBeen").innerText = "00:00";
                                document.getElementById("SinKingSongTime").innerText = "00:00";
                                //歌曲路径
                                SinKingMusic.Audio.src = res.Data.Url;
                                //加载信息
                                res.Data.Logo = res.Data.Logo == null || res.Data.Logo== undefined ? (UserMusicList.Singer).replace(",",""):res.Data.Logo+"?v=1.0";
                                res.Data.Logo = SinKingMusic.MainApiUrls.MusicImg + res.Data.Logo;
                                let Ele_MainLogo = document.getElementById("MainLogo").children[0];
                                Ele_MainLogo.style.backgroundImage = "url(" + res.Data.Logo + ")";
                                let Ele_SinKingMain = document.getElementById("SinKingMain").children[0];
                                Ele_SinKingMain.style.backgroundImage = "url(" + res.Data.Logo + ")";
                                Ele_MainLogo.parentElement.classList.remove("Ani-Logo");
                                //加载歌词
                                SinKingMusic.Lyric.Load(res.Data.Lrc);
                                setTimeout(function () {
                                    Ele_MainLogo.parentElement.classList.add("Ani-Logo");
                                    //启动歌词
                                    if (SinKingMusic.Lyric.Statu()) {
                                        SinKingMusic.Lyric.Timer.Start();
                                    } else {
                                        SinKingMusic.Lyric.Timer.Stop();
                                    }
                                }, 10);
                                //设置cookie
                                SinKingMusic.Cache.Set("SinKingMusicSheetID", SheetID);
                                SinKingMusic.Cache.Set("SinKingMusicMusicID", MusicID);
                                //识别RGB
                                SinKingMusic.RGB.Get(res.Data.Logo, function (rgb) {
                                    let color = 'rgba(' + rgb.dominant.replace("rgb(", "").replace(")", "") + ',0.7)';
                                    SinKingMusic.Ele.style.backgroundColor = color;
                                    let MusicTips = document.getElementById("MusicTips");
                                    MusicTips.style.backgroundColor = color;
                                    let MusicLyric = document.getElementById("MusicLyrics");
                                    MusicLyric.style.backgroundColor = color.replace("0.7", "0.5");
                                    let MusicButton = document.getElementById("MusicButton");
                                    MusicButton.style.backgroundColor = color.replace("0.7", "0.5");
                                    //判断色调
                                    if (SinKingMusic.RGB.Check(rgb.dominant)) {
                                        SinKingMusic.Player.Darken();
                                    } else {
                                        SinKingMusic.Player.Lighten();
                                    }
                                });
                                if (CallBack != null && CallBack != undefined) {
                                    CallBack(UserMusicList);
                                }
                                setTimeout(function () {
                                    //发送通知
                                    SinKingMusic.Tips.Show("正在播放 : " + UserMusicList.Name);
                                    SinKingMusic.Notice.Show(UserMusicList.Name, UserMusicList.Singer, res.Data.Logo);
                                }, 1000);
                            } catch (error) {
                                return error;
                            }
                        },
                        error: function () {
                            SinKingMusic.Tips.Show("歌曲资源不存在,正在播放下一首...");
                            SinKingMusic.Lyric.Close(false);
                            setTimeout(function(){
                                SinKingMusic.Buttons.NextMusic();
                            },200);
                        }
                    });
                } catch (error) {
                    return error;
                }
            }, 0);
        }
    },
    /*设置音量*/
    Voice: function (num = null) {
        if (num == null) {
            num = parseFloat(SinKingMusic.Cache.Get("SinKingMusicVolume"));
        }
        if (isNaN(num) || num <= 0) {
            num = 1;
        }
        SinKingMusic.Audio.volume = num;
        //设置进度条
        document.getElementById("MusicVoiceBeen").style.height = num * 100 + "px"
        SinKingMusic.Tips.Show("音量 : " + num * 100);
    },
    Buttons: {
        /*下一曲*/
        NextMusic: function (people = false) {
            let SheetID = SinKingMusic.Cache.Get("SinKingMusicSheetID");
            let MusicID = SinKingMusic.Cache.Get("SinKingMusicMusicID");
            let MusicInfo = SinKingMusic.MusicList.FindMusic(SheetID, MusicID);
            if (MusicInfo == null) {
                return false;
            }
            //获取播放方式
            let type = parseInt(SinKingMusic.Cache.Get("SinKingMusicPlayType"));
            switch (type) {
                case 0:
                    if (people) {
                        let index = MusicInfo.MusicIndex + 1;
                        if (index >= SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length) {
                            index = 0;
                        }
                        MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[index];
                    }
                    break;
                case 1:
                    let min = 0;
                    let max = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length - 1;
                    let id = parseInt(Math.random() * (max - min + 1) + min, 10);
                    MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[id];
                    break;
                default:
                    let index = MusicInfo.MusicIndex + 1;
                    if (index >= SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length) {
                        index = 0;
                    }
                    MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[index];
                    break;
            }
            SinKingMusic.Player.Load(SheetID, MusicInfo.ID, function () {
                SinKingMusic.Player.Start();
            });
        },
        /*上一曲*/
        LastMusic: function (people = false) {
            let SheetID = SinKingMusic.Cache.Get("SinKingMusicSheetID");
            let MusicID = SinKingMusic.Cache.Get("SinKingMusicMusicID");
            let MusicInfo = SinKingMusic.MusicList.FindMusic(SheetID, MusicID);
            if (MusicInfo == null) {
                return false;
            }
            //获取播放方式
            let type = parseInt(SinKingMusic.Cache.Get("SinKingMusicPlayType"));
            switch (type) {
                case 0:
                    if (people) {
                        let index = MusicInfo.MusicIndex - 1;
                        if (index >= SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length) {
                            index = 0;
                        }
                        MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[index];
                    }
                    break;
                case 1:
                    let min = 0;
                    let max = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length - 1;
                    let id = parseInt(Math.random() * (max - min + 1) + min, 10);
                    MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[id];
                    break;
                default:
                    let index = MusicInfo.MusicIndex - 1;
                    if (index < 0) {
                        index = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList.length - 1;
                    }
                    MusicInfo = SinKingMusic.MusicList.Data.Data[MusicInfo.SheetIndex].MusicList[index];
                    break;
            }
            if (MusicInfo == undefined) {
                return;
            }
            SinKingMusic.Player.Load(SheetID, MusicInfo.ID, function () {
                SinKingMusic.Player.Start();
            });
        },
        /*下一专辑*/
        NextSheet: function () {
            let SheetID = SinKingMusic.Cache.Get("SinKingMusicSheetID");
            let MusicID = SinKingMusic.Cache.Get("SinKingMusicMusicID");
            let MusicInfo = SinKingMusic.MusicList.FindMusic(SheetID, MusicID);
            if (MusicInfo == null) {
                return false;
            }
            let index = MusicInfo.SheetIndex + 1;
            if (index >= SinKingMusic.MusicList.Data.Data.length) {
                index = 0;
            }
            SinKingMusic.Player.Load(SinKingMusic.MusicList.Data.Data[index].ID, SinKingMusic.MusicList.Data.Data[index].MusicList[0].ID, function () {
                SinKingMusic.Player.Start();
            });
        },
        /*上一专辑*/
        LastSheet: function () {
            let SheetID = SinKingMusic.Cache.Get("SinKingMusicSheetID");
            let MusicID = SinKingMusic.Cache.Get("SinKingMusicMusicID");
            let MusicInfo = SinKingMusic.MusicList.FindMusic(SheetID, MusicID);
            if (MusicInfo == null) {
                return false;
            }
            let index = MusicInfo.SheetIndex - 1;
            if (index < 0) {
                index = SinKingMusic.MusicList.Data.Data.length - 1;
            }
            SinKingMusic.Player.Load(SinKingMusic.MusicList.Data.Data[index].ID, SinKingMusic.MusicList.Data.Data[index].MusicList[0].ID, function () {
                SinKingMusic.Player.Start();
            });
        },
        /*播放方式*/
        PlayType: {
            Ele: null,
            Init: function (id = null) {
                //播放方式初始化
                let ids = parseInt(SinKingMusic.Cache.Get("SinKingMusicPlayType"));
                let PlayType = isNaN(ids) ? parseInt(id) : parseInt(ids);
                switch (PlayType) {
                    case 0:
                        this.Single();
                        break;
                    case 1:
                        this.Random();
                        break;
                    default:
                        this.Sheet();
                        break;
                }
            },
            Change: function () {
                let types = ["Single", "Random", "Sheet"];
                let type = parseInt(SinKingMusic.Cache.Get("SinKingMusicPlayType"));
                if (isNaN(type)) {
                    SinKingMusic.Buttons.PlayType.Single();
                    return true;
                }
                if (type == types.length - 1) {
                    type = 0;
                } else {
                    type++;
                }
                if (type < types.length) {
                    eval("SinKingMusic.Buttons.PlayType." + types[type] + "()");
                }
            },
            Single: function () {
                SinKingMusic.Cache.Set("SinKingMusicPlayType", 0);
                this.Ele[0].innerText = "单曲循环";
                SinKingMusic.Tips.Show("播放模式 : 单曲循环");
            },
            Random: function () {
                SinKingMusic.Cache.Set("SinKingMusicPlayType", 1);
                this.Ele[0].innerText = "随机播放";
                SinKingMusic.Tips.Show("播放模式 : 随机播放");
            },
            Sheet: function () {
                SinKingMusic.Cache.Set("SinKingMusicPlayType", 2);
                this.Ele[0].innerText = "列表循环";
                SinKingMusic.Tips.Show("播放模式 : 列表循环");
            }
        }
    },
    Ele: document.getElementById("SinKingMusicPlayer"),
    /*Ajax请求*/
    Ajax: function (params) {
        params = params || {};
        params.data = params.data || {};
        var _json = params.jsonp ? jsonp(params) : json(params); // 判断是json还是jsonp
        function json(params) { // 普通请求
            params.type = (params.type || 'GET').toUpperCase(); // 设置请求默认类型
            var urlData = formatParams(params.data); // 对数据进行格式化
            var xhr = null; // 对xhr进行初始化
            if (window.XMLHttpRequest) {
                xhr = new window.XMLHttpRequest();
            } else {
                xhr = new ActiveXObject('Microsoft.XMLHTTP');
            }
            var headers = params.headers || {};
            if (params.type === 'GET') {
                xhr.open(params.type, params.url + '?' + urlData, true);
                setHeaders(xhr, headers);
                xhr.send(null);
            } else {
                xhr.open(params.type, params.url, true);
                setHeaders(xhr, headers);
                xhr.send(JSON.stringify(params.data));
            }
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    var status = xhr.status;
                    if (status >= 200 && status < 300) {
                        var response = '';
                        var type = xhr.getResponseHeader('Content-Type');
                        if (type.indexOf('xml') !== -1 && xhr.responseXML) { // xml格式
                            response = xhr.responseXML;
                        } else if (type.indexOf('application/json') !== -1) { // JSON格式
                            response = JSON.parse(xhr.responseText);
                        } else {
                            response = xhr.responseText; // 字符串格式
                        }
                        params.success && params.success(response);
                    } else {
                        params.error && params.error(status);
                    }
                }
            }
        }
        function jsonp(params) {
            var callbackName = params.jsonp; // 回调函数名
            var head = document.getElementsByTagName('head')[0];
            params.data['callback'] = callbackName;
            var data = formatParams(params.data);
            var script = document.createElement('script');
            head.appendChild(script);
            window[callbackName] = function (json) {
                head.removeChild(script);
                clearTimeout(script.timer);
                window[callbackName] = null;
                params.success && params.success(json);
            };
            script.src = params.url + '?' + data;
            if (params.time) {
                script.timer = setTimeout(function () {
                    window[callbackName] = null;
                    head.removeChild(script);
                    params.error && params.error({
                        message: '超时'
                    })
                }, params.time)
            }
        }
        function formatParams(data) {
            var arr = [];
            for (var key in data) {
                arr.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
            }
            return arr.join('&');
        }
        function setHeaders(xhr, headers) {
            for (var key in headers) {
                xhr.setRequestHeader(key, headers[key]);
            }
        }
    },
    /*缓存操作*/
    Cache: {
        Set: function (name, value) {
            window.localStorage.setItem(name, value);
        },
        Get: function (name) {
            let temp = window.localStorage.getItem(name);
            if (temp) {
                return temp;
            } else {
                return null;
            }
        },
        Delete: function (name) {
            window.localStorage.removeItem(name);
        }
    },
    /*RGB提取*/
    RGB: {
        Check: function (rgb) {
            var RgbValue = rgb.replace("rgb(", "").replace(")", "");
            var RgbValueArry = RgbValue.split(",");
            var grayLevel = RgbValueArry[0] * 0.299 + RgbValueArry[1] * 0.587 + RgbValueArry[2] * 0.114;
            if (grayLevel >= 192) {
                return true;
            } else {
                return false;
            }
        },
        Get: function (src, callback = null) {
            let ele = document.createElement("img");
            ele.src = src;
            RGBaster.colors(ele, {
                success: function (rgb) {
                    if (callback != null && callback != undefined) {
                        callback(rgb);
                    }
                }
            });
        }
    },
    /*格式转换*/
    timeToMinute: function (times) {
        try {
            var t;
            if (times > -1) {
                var hour = Math.floor(times / 3600);
                var min = Math.floor(times / 60) % 60;
                var sec = times % 60;
                if (hour < 10) {
                    t = '0' + hour + ":";
                } else {
                    t = hour + ":";
                }
                if (min < 10) { t += "0"; }
                t += min + ":";
                if (sec < 10) { t += "0"; }
                t += sec.toFixed(2);
            }
            t = t.substring(3, t.length - 3);
            return t;
        } catch (error) {
            return error;
        }
    },
    /*播放器状态*/
    PlayerStatu: {
        Ele: null,
        Statu: function () {
            return this.Ele.classList.contains("rovate-180");
        },
        Open: function () {
            SinKingMusic.Ele.classList.remove("Close");
            SinKingMusic.Ele.classList.add("Open");
            this.Ele.classList.remove("rovate-180");
        },
        Close: function () {
            SinKingMusic.Ele.classList.remove("Open");
            SinKingMusic.Ele.classList.add("Close");
            this.Ele.classList.add("rovate-180");
        },
        Toggle: function () {
            if (!this.Statu()) {
                this.Close();
            } else {
                this.Open();
            }
        }
    },
    /*歌曲列表状态*/
    MusicListStatu: {
        Ele: null,
        Statu: function () {
            return parseInt(this.Ele.offsetHeight) > 0;
        },
        Open: function () {
            this.Ele.style.height = "285px";
        },
        Close: function () {
            this.Ele.style.height = "0px";
        },
        Toggle: function () {
            if (this.Statu()) {
                this.Close();
            } else {
                this.Open();
            }
        }
    },
    /*歌单加载*/
    MusicList: {
        Timer: null,
        FindMusic: function (SheetID, MusicID) {
            //查找歌单
            let Music = SinKingMusic.MusicList.Data.Data;
            let UserMusic = null;
            let UserMusicList = null;
            let SheetIndex = null;
            for (let index = 0; index < Music.length; index++) {
                if (Music[index].ID == SheetID) {
                    UserMusic = Music[index];
                    SheetIndex = index;
                    break;
                }
            }
            if (UserMusic == null) {
                return null;
            }
            //查找歌曲
            for (let index = 0; index < UserMusic.MusicList.length; index++) {
                let MusicInfo = UserMusic.MusicList[index];
                if (MusicInfo.ID == MusicID) {
                    UserMusicList = MusicInfo;
                    UserMusicList.MusicIndex = index;
                    UserMusicList.SheetIndex = SheetIndex;
                    break;
                }
            }
            if (UserMusicList == null) {
                return null;
            }
            return UserMusicList;
        },
        LoadData: function (id, CallBack = null) {
            SinKingMusic.Ajax({
                url: SinKingMusic.MainApiDomain + SinKingMusic.MainApiUrls.MusicList,
                data: {
                    callback: "MusicList",
                    type: "jsonp",
                    id: id
                },
                jsonp: 'MusicList',
                time: 20000,
                success(res) {
                    SinKingMusic.MusicList.Data = res;
                    if (CallBack != null && CallBack != undefined) {
                        CallBack(res);
                    }
                }
            });
        },
        LoadSongSheets: function () {
            setTimeout(function () {
                //加载列表
                let ele = document.getElementById("LoadSongSheets");
                let parent = document.getElementById("SongSheets").parentElement;
                parent.classList.remove("MusicOpen");
                let list = SinKingMusic.MusicList.Data.Data;
                let index = 0;
                clearInterval(SinKingMusic.MusicList.Timer);
                ele.innerHTML = "";
                SinKingMusic.MusicList.Timer = setInterval(function () {
                    if (index >= list.length) {
                        clearInterval(SinKingMusic.MusicList.Timer);
                        SinKingMusic.MusicList.Timer = setTimeout(function () {
                            document.getElementById("SongList").style.display = "none";
                        }, 300);
                        return;
                    }
                    let info = list[index];
                    let dom = document.createElement("li");
                    dom.innerText = (index + 1) + " . " + info.Name;
                    dom.onclick = function () {
                        SinKingMusic.MusicList.LoadSongLists(info.ID);
                    }
                    ele.append(dom);
                    index++;
                }, 1);
                //加载标题
                let Sheet = document.getElementById("SongSheetInfo");
                Sheet.children[0].children[0].classList.add("rovate-180");
                Sheet.children[1].innerText = SinKingMusic.MusicList.Data.Name;
                //绑定事件
                document.getElementById("SongSheetInfo").onclick = null;
            }, 0);
        },
        LoadSongLists: function (id) {
            setTimeout(function () {
                //加载列表
                let list = SinKingMusic.MusicList.Data.Data;
                let music = document.getElementById("LoadMusicLists");
                let music_contain = document.getElementById("SongList");
                music_contain.parentElement.classList.add("MusicOpen");
                music_contain.style.display = "block";
                let info = null;
                for (let index = 0; index < list.length; index++) {
                    if (list[index].ID == id) {
                        info = list[index];
                        break;
                    }
                }
                if (info == null) {
                    return false;
                }
                let index = 0;
                clearInterval(SinKingMusic.MusicList.Timer);
                music.innerHTML = "";
                SinKingMusic.MusicList.Timer = setInterval(function () {
                    if (index >= info.MusicList.length) {
                        clearInterval(SinKingMusic.MusicList.Timer);
                        return;
                    }
                    let musicinfo = info.MusicList[index];
                    let dom = document.createElement("li");
                    dom.innerText = (index + 1) + " . " + musicinfo.Name;
                    dom.onclick = function () {
                        SinKingMusic.Player.Play(id, musicinfo.ID);
                    }
                    music.append(dom);
                    index++;
                }, 1);
                //加载标题
                let Sheet = document.getElementById("SongSheetInfo");
                Sheet.children[0].children[0].classList.remove("rovate-180");
                Sheet.children[1].innerText = info.Name;
                //绑定事件
                document.getElementById("SongSheetInfo").onclick = function () {
                    SinKingMusic.MusicList.LoadSongSheets();
                }
            }, 0);
        },
        Data: {}
    },
    /*播放器提示*/
    Tips: {
        Ele: null,
        Timer: null,
        Show: function (text) {
            clearTimeout(this.Timer);
            var dom = this.Ele;
            dom.innerText = text;
            dom.classList.remove("Close");
            dom.classList.add("Open");
            this.Timer = setTimeout(function () {
                dom.classList.remove("Open");
                dom.classList.add("Close");
            }, 3000);
        }
    },
    /*桌面通知*/
    Notice: {
        Show: function (msg, content, img) {
            this.Tip(msg, {
                dir: "auto",
                body: content,
                requireInteraction: true,
                icon: img
            });
        },
        Tip: function (title, options) {
            if (window.Notification) {
                if (Notification.permission === 'granted') {
                    new Notification(title, options);
                } else if (Notification.permission === 'default') {
                    Notification.requestPermission().then(permission => {
                        if (permission === 'granted') {
                            new Notification(title, options);
                        }
                    });
                }
            }
        }
    },
    /*歌词操作*/
    Lyric: {
        Ele: null,
        Init: function (status) {
            let statu = parseInt(SinKingMusic.Cache.Get("SinKingMusicLyric"));
            if (isNaN(statu)) {
                if (status) {
                    statu = 1;
                } else {
                    statu = 0;
                }
            }
            if (statu == 1) {
                this.Open();
            } else {
                this.Close();
            }
        },
        Statu: function () {
            return this.Ele[1].classList.contains("off");
        },
        Open: function (cache = true) {
            if (cache) {
                SinKingMusic.Cache.Set("SinKingMusicLyric", 1);
            }
            this.Ele[0].innerText = "歌词开启";
            this.Ele[0].parentNode.children[0].classList.remove("fail");
            this.Ele[0].parentNode.children[0].classList.add("succ");
            this.Ele[1].classList.remove("on");
            this.Ele[1].classList.add("off");
            this.Ele[2].classList.remove("Close");
            this.Ele[2].classList.add("Open");
            SinKingMusic.Lyric.Timer.Start();
            SinKingMusic.Tips.Show("歌词开启");
        },
        Close: function (cache = true) {
            if (cache) {
                SinKingMusic.Cache.Set("SinKingMusicLyric", 0);
            }
            this.Ele[0].innerText = "歌词关闭";
            this.Ele[0].parentNode.children[0].classList.remove("succ");
            this.Ele[0].parentNode.children[0].classList.add("fail");
            this.Ele[1].classList.remove("off");
            this.Ele[1].classList.add("on");
            this.Ele[2].classList.remove("Open");
            this.Ele[2].classList.add("Close");
            SinKingMusic.Tips.Show("歌词关闭");
        },
        Toggle: function () {
            if (this.Statu()) {
                this.Close();
            } else {
                this.Open();
            }
        },
        Data: null,
        Timer: {
            timer: null,//定时器
            Start: function () {
                this.Stop();
                this.timer = setInterval(function () {
                    //更改歌词
                    let time = SinKingMusic.Audio.currentTime.toString().split('.')[0];
                    try {
                        let line = SinKingMusic.Lyric.Data[time];
                        if (line != undefined && line != null) {
                            SinKingMusic.Lyric.Ele[2].children[0].children[0].innerHTML = line.content;
                        }
                    } catch (error) {
                        return error;
                    }
                }, 1000);
            },
            Stop: function () {
                clearInterval(this.timer);
            }
        },
        Load: function (Content) {
            SinKingMusic.Lyric.Ele[2].children[0].children[0].innerText = "歌词解析中...";
            //歌词排序
            if (Content == null || Content == undefined || Content == "") {
                SinKingMusic.Lyric.Close(false);
                SinKingMusic.Lyric.Data = new Array();
                SinKingMusic.Lyric.Ele[2].children[0].children[0].innerText = "轻音乐 请欣赏";
                return false;
            }
            if (parseInt(SinKingMusic.Cache.Get("SinKingMusicLyric")) == 1) {
                SinKingMusic.Lyric.Open(false);
            }
            let lines = Content.split('\n');
            let offset = null;//偏移量
            let txts = new Array();
            let txts_index = 0;
            for (let index = 0; index < lines.length; index++) {
                let line = lines[index];
                if (line == null || line == "") {
                    continue;
                }
                let content = line.replace(/\[.*?\]/g, '');
                let times = line.match(/\[(.+?)\]/g);
                if (times == null || times == "" || content == null || content == "") {
                    continue;
                }
                //遍历time
                for (let i = 0; i < times.length; i++) {
                    let time = times[i].replace(/\[|]/g, '');
                    if (time.indexOf('offset') >= 0) {
                        offset = parseInt(time.split(':')[1]);//计算偏移量
                        continue;
                    }
                    if (time.indexOf('ti') < 0 && time.indexOf('ar') < 0 && time.indexOf('al') < 0 && time.indexOf('by') < 0) {
                        let i = time.split(':')[0];
                        let s = time.split(':')[1];
                        //计算毫秒
                        let ss = parseInt(s.split('.')[0]) * 1000 + parseInt(s.split('.')[1]) + i * 60 * 1000 + offset;
                        let txt = "";
                        for (let index = 0; index < content.length; index++) {
                            if(content[index]==" "){
                                txt += '<span class="Letter">&nbsp;</span>';
                            }else{
                                txt += '<span class="Letter">' + content[index] + '</span>';
                            }
                        }
                        txts[txts_index] = { time: ss, content: txt };
                        txts_index++;
                    }
                }
            }
            //数组排序
            txts.sort(function (obj1, obj2) {
                var val1 = obj1.time;
                var val2 = obj2.time;
                if (val1 < val2) {
                    return -1;
                } else if (val1 > val2) {
                    return 1;
                } else {
                    return 0;
                }
            });
            //更改下标
            let lyrics = new Array();
            for (let index = 0; index < txts.length; index++) {
                let second = (txts[index].time / 1000).toString().split('.')[0];
                lyrics[second] = txts[index];
            }
            delete txts;
            SinKingMusic.Lyric.Ele[2].children[0].children[0].innerText = "歌词解析成功...";
            //添加进对象
            SinKingMusic.Lyric.Data = lyrics;
        }
    },
    /*初始化*/
    Init: function (id) {
        //歌曲进度条按钮
        let MusicTimeBtn = document.getElementById("MusicTimeBtn");
        //歌曲进度条
        let MusicProcess = document.getElementById("MusicProcess");
        //歌曲进度条已播放
        let MusicProcessBtn = document.getElementById("MusicProcessBtn");
        //进度条总长度
        let MusicMainProcess = document.getElementById("MusicMainProcess");
        MusicTimeBtn.onmousedown = function (e) {
            let disx = e.clientX - MusicTimeBtn.offsetLeft;
            document.onmousemove = function (e) {
                try {
                    let movex = e.clientX - disx + 8;
                    if (movex < 0) {
                        movex = 0;
                    } else if (movex > window.innerWidth - MusicTimeBtn.offsetWidth) {
                        movex = window.innerWidth - MusicTimeBtn.offsetWidth
                    }
                    let point = parseFloat(movex) / parseInt(MusicProcess.offsetWidth);
                    if (point >= 1) {
                        return;
                    }
                    SinKingMusic.Audio.currentTime = parseFloat(movex / MusicMainProcess.offsetWidth) * SinKingMusic.Audio.duration
                    SinKingMusic.Tips.Show("歌曲已定位 : " + SinKingMusic.timeToMinute(SinKingMusic.Audio.currentTime));
                    MusicProcessBtn.style.width = movex + "px";
                    let lefts = MusicTimeBtn.style.left = movex + "px";
                } catch (error) {
                    return error;
                }
            }
            document.onmouseup = function () {
                this.onmousemove = null;
                this.onmousedown = null;
            }
        }
        let mobile_touch;
        MusicTimeBtn.addEventListener("touchstart",function(e){
            e = e.changedTouches[0];
            mobile_touch = e.clientX - MusicTimeBtn.offsetLeft;
        });
        MusicTimeBtn.addEventListener("touchmove",function(e){
            e = e.changedTouches[0];
            let movex = e.clientX - mobile_touch + 8;
            if (movex < 0) {
                movex = 0;
            } else if (movex > window.innerWidth - MusicTimeBtn.offsetWidth) {
                movex = window.innerWidth - MusicTimeBtn.offsetWidth
            }
            let point = parseFloat(movex) / parseInt(MusicProcess.offsetWidth);
            if (point >= 1) {
                return;
            }
            SinKingMusic.Audio.currentTime = parseFloat(movex / MusicMainProcess.offsetWidth) * SinKingMusic.Audio.duration
            SinKingMusic.Tips.Show("歌曲已定位 : " + SinKingMusic.timeToMinute(SinKingMusic.Audio.currentTime));
            MusicProcessBtn.style.width = movex + "px";
            MusicTimeBtn.style.left = movex + "px";
        });
        MusicProcess.onclick = function (e) {
            try {
                MusicTimeBtn.style.left = e.offsetX + "px";
                MusicProcessBtn.style.width = e.offsetX + "px";
                SinKingMusic.Audio.currentTime = parseFloat(e.offsetX / MusicMainProcess.offsetWidth) * SinKingMusic.Audio.duration
                SinKingMusic.Tips.Show("歌曲已定位 : " + SinKingMusic.timeToMinute(SinKingMusic.Audio.currentTime));
            } catch (error) {
                return error;
            }
        }
        MusicProcessBtn.onclick = function (e) {
            try {
                MusicTimeBtn.style.left = e.offsetX + "px";
                MusicProcessBtn.style.width = e.offsetX + "px";
                SinKingMusic.Audio.currentTime = parseFloat(e.offsetX / MusicMainProcess.offsetWidth) * SinKingMusic.Audio.duration
                SinKingMusic.Tips.Show("歌曲已定位 : " + SinKingMusic.timeToMinute(SinKingMusic.Audio.currentTime));
            } catch (error) {
                return error;
            }
        }
        //音量图标
        let MusicVoiceBtn = document.getElementById("MusicVoiceBtn");
        let MusicVoiceBeen = document.getElementById("MusicVoiceBeen");
        MusicVoiceBtn.onmousedown = function (e) {
            let disy = e.clientY - MusicVoiceBtn.offsetTop - MusicVoiceBeen.offsetTop;
            document.onmousemove = function (e) {
                let movey = e.clientY - disy;
                if (movey < 0) {
                    movey = 0;
                }
                movey = parseInt(movey);
                movey = 100 - movey;
                if (movey <= 1) {
                    movey = 0;
                }
                SinKingMusic.Audio.volume = parseFloat(movey / 100).toFixed(2);
                SinKingMusic.Cache.Set("SinKingMusicVolume", parseFloat(movey / 100).toFixed(2));
                MusicVoiceBeen.style.height = movey + "px";
                SinKingMusic.Tips.Show("音量 : " + movey);
            }
            document.onmouseup = function () {
                this.onmousemove = null;
                this.onmousedown = null;
            }
        }
        let mobile_touch2;
        MusicVoiceBtn.addEventListener("touchstart",function(e){
            e = e.changedTouches[0];
            mobile_touch2 = e.clientY - MusicVoiceBtn.offsetTop - MusicVoiceBeen.offsetTop;
        });
        MusicVoiceBtn.addEventListener("touchmove",function(e){
            e = e.changedTouches[0];
            let movey = e.clientY - mobile_touch2;
            movey = parseInt(movey);
            if (movey < 0) {
                movey = 0;
            }
            movey = 100 - movey;
            if (movey <= 1) {
                movey = 0;
            }
            SinKingMusic.Audio.volume = parseFloat(movey / 100).toFixed(2);
            SinKingMusic.Cache.Set("SinKingMusicVolume", parseFloat(movey / 100).toFixed(2));
            MusicVoiceBeen.style.height = movey + "px";
            SinKingMusic.Tips.Show("音量 : " + movey);
        });
            //RGB提取
            ;
        (function (window, undefined) {
            "use strict";
            var getContext = function (width, height) {
                var canvas = document.createElement("canvas");
                canvas.setAttribute('width', width);
                canvas.setAttribute('height', height);
                return canvas.getContext('2d');
            };
            var getImageData = function (img, loaded) {
                var imgObj = new Image();
                var imgSrc = img.src || img;
                if (imgSrc.substring(0, 5) !== 'data:')
                    imgObj.crossOrigin = "Anonymous";
                imgObj.onload = function () {
                    var context = getContext(imgObj.width, imgObj.height);
                    context.drawImage(imgObj, 0, 0);

                    var imageData = context.getImageData(0, 0, imgObj.width, imgObj.height);
                    loaded && loaded(imageData.data);
                };
                imgObj.src = imgSrc;

            };
            var makeRGB = function (name) {
                return ['rgb(', name, ')'].join('');
            };
            var mapPalette = function (palette) {
                var arr = [];
                for (var prop in palette) {
                    arr.push(frmtPobj(prop, palette[prop]))
                };
                arr.sort(function (a, b) {
                    return (b.count - a.count)
                });
                return arr;
            };
            var fitPalette = function (arr, fitSize) {
                if (arr.length > fitSize) {
                    return arr.slice(0, fitSize);
                } else {
                    for (var i = arr.length - 1; i < fitSize - 1; i++) {
                        arr.push(frmtPobj('0,0,0', 0))
                    };
                    return arr;
                };
            };
            var frmtPobj = function (a, b) {
                return {
                    name: makeRGB(a),
                    count: b
                };
            }
            var PALETTESIZE = 10;
            var RGBaster = {};
            RGBaster.colors = function (img, opts) {
                opts = opts || {};
                var exclude = opts.exclude || [],
                    paletteSize = opts.paletteSize || PALETTESIZE;
                getImageData(img, function (data) {
                    var colorCounts = {},
                        rgbString = '',
                        rgb = [],
                        colors = {
                            dominant: {
                                name: '',
                                count: 0
                            },
                            palette: []
                        };
                    var i = 0;
                    for (; i < data.length; i += 4) {
                        rgb[0] = data[i];
                        rgb[1] = data[i + 1];
                        rgb[2] = data[i + 2];
                        rgbString = rgb.join(",");
                        if (rgb.indexOf(undefined) !== -1 || data[i + 3] === 0) {
                            continue;
                        }
                        if (exclude.indexOf(makeRGB(rgbString)) === -1) {
                            if (rgbString in colorCounts) {
                                colorCounts[rgbString] = colorCounts[rgbString] + 1;
                            } else {
                                colorCounts[rgbString] = 1;
                            }
                        }
                    }
                    if (opts.success) {
                        var palette = fitPalette(mapPalette(colorCounts), paletteSize + 1);
                        opts.success({
                            dominant: palette[0].name,
                            secondary: palette[1].name,
                            palette: palette.map(function (c) {
                                return c.name;
                            }).slice(1)
                        });
                    }
                });
            };
            window.RGBaster = window.RGBaster || RGBaster;
        })(window);
        let MainInfo = document.getElementById("MainInfo");
        //绑定面板事件
        MainInfo.addEventListener("dblclick",function(){
            SinKingMusic.Player.StyleToggle();
        });
        //播放器初始化
        SinKingMusic.MusicList.LoadData(id, function (res) {
            setTimeout(function () {
                //加载列表
                SinKingMusic.MusicList.LoadSongSheets();
                //启动定时器
                SinKingMusic.Timer.Start();
                //加载播放模式
                SinKingMusic.Buttons.PlayType.Init(res.PlayType);
                //加载音量
                let nums = parseFloat(SinKingMusic.Cache.Get("SinKingMusicVolume"));
                if (isNaN(nums)) {
                    SinKingMusic.Voice(parseFloat(res.Voice / 100));
                } else {
                    SinKingMusic.Voice(nums);
                }
                //加载歌词
                SinKingMusic.Lyric.Init(res.Lyric);
                //加载音乐
                setTimeout(function () {
                    SinKingMusic.Player.Load(null, null, function () {
                        //歌曲定位
                        let time = parseFloat(SinKingMusic.Cache.Get("SinKingMusicCurrentTime"));
                        if (isNaN(time)) {
                            time = 0;
                        }
                        SinKingMusic.Audio.currentTime = time;
                        //是否播放
                        if (parseInt(SinKingMusic.Cache.Get("SinKingMusicPlayStatus")) == 0) {
                            SinKingMusic.Player.Stop();
                        } else {
                            SinKingMusic.Player.Start();
                        }
                    });
                }, 200);
                setTimeout(function () {
                    SinKingMusic.Tips.Show(res.Word);
                }, 2000);
            }, 200);
        });
    }
}
function SinKingMusicLoad() {
    SinKingMusic.Start(function () {
        let id = parseInt(document.getElementById("SinKingMusic").getAttribute("key"));
        SinKingMusic.PlayerStatu.Toggle();
        SinKingMusic.MusicListStatu.Toggle();
        SinKingMusic.Init(id);
        console.log('\n' + ' %c SinKingMusic Beat %c https://music.clwl.online 沉沦云网络 ' + '\n', 'color: #fadfa3; background: #030307; padding:5px 0;', 'background: #fadfa3; padding:5px 0;; padding:5px 0');
    });
}
function SinKingaddLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = func;
    } else {
        window.onload = function () {
            oldonload();
            func();
        }
    }

}
SinKingaddLoadEvent(SinKingMusicLoad);