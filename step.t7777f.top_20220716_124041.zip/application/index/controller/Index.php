<?php
namespace app\index\controller;

class Index extends Base
{
    public function index()
    {
        return view();
    }
    public function login()
    {
        return view();
    }
    public function reg()
    {
        return view();
    }
}
